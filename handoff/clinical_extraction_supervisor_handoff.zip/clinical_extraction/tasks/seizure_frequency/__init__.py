"""Seizure-frequency extraction tasks."""
