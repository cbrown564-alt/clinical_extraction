"""Clinical assessment assembly submodules."""
