"""Assessment burden normalization submodules."""
