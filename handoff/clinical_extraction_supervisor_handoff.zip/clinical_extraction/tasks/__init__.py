"""Clinical extraction task implementations."""
